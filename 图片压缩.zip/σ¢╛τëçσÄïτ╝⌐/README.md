> 本库不再维护，已更新更适合的版本。[lrz3](https://github.com/think2011/localResizeIMG3)


## 留念demo
![图1](http://think2011.qiniudn.com/LocalResizeIMG1.gif)


demo
---
具体详情请查看 源代码，或者 [demo](http://think2011.github.io/localResizeIMG/)。

## PS
这是8个月前的测试文章的延伸，[点我去看看](http://my.oschina.net/hzplay/blog/160806)。


> ##### 技术： jquery
> ##### 时间： 2014年5月
> ##### 博客： [think2011](http://think2011.github.io)
