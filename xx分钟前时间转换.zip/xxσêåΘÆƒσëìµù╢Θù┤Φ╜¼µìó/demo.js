//标准时间格式字符串转换为时间戳
//传入格式为 2017-05-31 14:30:45
function getDateTimeStamp (dateStr) {
    return (Date.parse(dateStr.replace(/-/gi,"/"))/1000)
}
//将返回的时间戳与当前时间戳进行比较，转换成几秒前、几分钟前、几小时前、几天前的形式。
function getDateDiff(dateStr){
    var data=getDateTimeStamp(dateStr)
    var d_minutes,d_hours,d_days;
    var timeNow = parseInt(new Date().getTime()/1000);  //转换为服务器当前时间戳       
    var d;
    d = timeNow - data;
    d_days = parseInt(d/86400);
    d_hours = parseInt(d/3600);
    d_minutes = parseInt(d/60);
    if(d_days>0 && d_days<4){         
        return d_days+"天前";         
    }else if(d_days<=0 && d_hours>0){         
        return d_hours+"小时前";         
    }else if(d_hours<=0 && d_minutes>0){         
        return d_minutes+"分钟前";
    }else{         
        var s = new Date(data*1000);         
        //return s.getFullYear()+"年";
        return (s.getFullYear()+"年"+s.getMonth()+1)+"月"+s.getDate()+"日";         
    }         
}  